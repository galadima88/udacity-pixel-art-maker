# Pixel-Art-Maker-project
Udacity Pixel Art Maker project using basic HTML, CSS, JQuery to complete this project.
 https://umabubakar16.github.io/my-udacity-pixel-art/.
